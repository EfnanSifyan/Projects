package efnansifyan.mis.a201735042efnansifyan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private  String selectedTopicName ="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // buton ve layoutların id atamaları yapıldı.
        final LinearLayout wind = findViewById(R.id.windLayout);
        final LinearLayout keyed = findViewById(R.id.keyedLayout);
        final LinearLayout stringed = findViewById(R.id.stringedLayout);
        final LinearLayout percussion = findViewById(R.id.percussionLayout);
        final Button startBtn = findViewById(R.id.StartQuizBtn);

        //wind seçeneği seçildiğindeki renk atamaları yapıldı.
        wind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedTopicName ="wind";
                wind.setBackgroundResource(R.drawable.round_back_white_stroke);
                keyed.setBackgroundResource(R.drawable.round_back_white);
                stringed.setBackgroundResource(R.drawable.round_back_white);
                percussion.setBackgroundResource(R.drawable.round_back_white);


            }
        });
         //keyed seçeneği seçildiğindeki renk atamaları yapıldı.
        keyed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedTopicName ="keyed";

                keyed.setBackgroundResource(R.drawable.round_back_white_stroke);

                wind.setBackgroundResource(R.drawable.round_back_white);
                stringed.setBackgroundResource(R.drawable.round_back_white);
                percussion.setBackgroundResource(R.drawable.round_back_white);


            }
        });
        //stringed seçeneği seçildiğindeki renk atamaları yapıldı.
        stringed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedTopicName ="stringed";

                stringed.setBackgroundResource(R.drawable.round_back_white_stroke);

                keyed.setBackgroundResource(R.drawable.round_back_white);
                wind.setBackgroundResource(R.drawable.round_back_white);
                percussion.setBackgroundResource(R.drawable.round_back_white);


            }
        });

        //Percussion seçeneği seçildiğindeki renk atamaları yapıldı.
        percussion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedTopicName ="percussion";

                percussion.setBackgroundResource(R.drawable.round_back_white_stroke);

                keyed.setBackgroundResource(R.drawable.round_back_white);
                wind.setBackgroundResource(R.drawable.round_back_white);
                wind.setBackgroundResource(R.drawable.round_back_white);


            }
        });

        //Toast Bilgilendirme mesajı
        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedTopicName.isEmpty()){
                    Toast.makeText(MainActivity.this,"Please Select the Topic",Toast.LENGTH_SHORT).show();
                }

                else{
                    Intent intent = new Intent(MainActivity.this,QuizActivity.class);
                    intent.putExtra("selectedTopic",selectedTopicName);
                    startActivity(intent);
                }
            }
        });

    }
}